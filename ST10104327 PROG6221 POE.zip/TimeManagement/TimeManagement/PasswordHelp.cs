﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Security.Cryptography;
using System.Text;
using System.Windows.Controls;
using System.Windows;

namespace TimeManagement
{
    internal class PasswordHelp
    {
        public class PasswordHelper
        {
            public static string HashPassword(string password)
            {
                using (SHA256 sha256 = SHA256.Create())
                {
                    byte[] hashedBytes = sha256.ComputeHash(Encoding.UTF8.GetBytes(password));

                    // Convert the byte array to a hexadecimal string representation.
                    StringBuilder builder = new StringBuilder();
                    for (int i = 0; i < hashedBytes.Length; i++)
                    {
                        builder.Append(hashedBytes[i].ToString("x2"));
                    }
                    return builder.ToString();
                }
            }
            private void RegisterButton_Click(object sender, RoutedEventArgs e)
            {
                string username = UsernameTextBox.Text;
                string password = PasswordBox.Password;

                // Hash the password using the PasswordHelper class.
                string hashedPassword = PasswordHelper.HashPassword(password);

                using ( context = new ())
                {
                    var user = new User { Username = username, Password = hashedPassword };
                    context.Users.Add(user);
                    context.SaveChanges();
                    MessageBox.Show("Registration successful!");
                }
            }

        }

    }
}
