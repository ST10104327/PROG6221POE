﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace TimeManagement
{
    /// <summary>
    /// Interaction logic for user_regestration.xaml
    /// </summary>
    public partial class user_regestration : Window
    {
        public user_regestration()
        {
            InitializeComponent();
        }
        private void RegisterButton_Click(object sender, RoutedEventArgs e)
        {
            string username = UsernameTextBox.Text;
            string password = PasswordBox.Password;

            // Validate user input (e.g., check for empty fields, password complexity).
            if (string.IsNullOrWhiteSpace(username) || string.IsNullOrWhiteSpace(password))
            {
                MessageBox.Show("Please fill in all fields.");
                return;
            }

            using (context = new())
            {
                // Check if the username is already in use.
                if (context.Users.Any(u => u.Username == username))
                {
                    MessageBox.Show("Username already in use. Please choose another.");
                }
                else
                {
                    // Create a new user and save it to the database.
                    User newUser = new User { Username = username, Password = password };
                    context.Users.Add(newUser);
                    context.SaveChanges();
                    MessageBox.Show("Registration successful!");
                }
            }

           static void TextBox_GotFocus(object sender, RoutedEventArgs e)
            {
                TextBox textBox = (TextBox)sender;
                if (textBox.Text == "Enter username")
                {
                    textBox.Text = "";
                    textBox.Foreground = System.Windows.Media.Brushes.Black;
                }
            }

        void TextBox_LostFocus(object sender, RoutedEventArgs e)
            {
                TextBox textBox = (TextBox)sender;
                if (string.IsNullOrWhiteSpace(textBox.Text))
                {
                    textBox.Text = "Enter username";
                    textBox.Foreground = System.Windows.Media.Brushes.Gray;
                }
            }

           void PasswordBox_PasswordChanged(object sender, RoutedEventArgs e)
            {
                PasswordBox passwordBox = (PasswordBox)sender;
                if (string.IsNullOrWhiteSpace(passwordBox.Password))
                {
                    passwordBox.Tag = "Enter password";
                    passwordBox.Foreground = System.Windows.Media.Brushes.Gray;
                }
                else
                {
                    passwordBox.Tag = null;
                    passwordBox.Foreground = System.Windows.Media.Brushes.Black;
                }
            }

            void RegisterButton_Click(object sender, RoutedEventArgs e)
            {
                // Handle registration logic here
            }
        }
    }
    }
