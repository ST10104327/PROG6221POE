﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Input;

namespace TimeManagement
{
    public class MainViewModel : MainViewModelBase, IMainViewModel
    {
        private string _ingredientFilter;

        public ICommand ApplyFilterCommand { get; set; }

        private string _selectedFoodGroup;
        private int? _maxCalories;
        internal static readonly object Modules;

        public string IngredientFilter
        {
            get => _ingredientFilter;
            set
            {
                _ingredientFilter = value;
                OnPropertyChanged(nameof(IngredientFilter));
                UpdateFilteredModules();
            }
        }

        private void OnPropertyChanged(string v)
        {
            throw new NotImplementedException();
        }

        public int? MaxCalories
        {
            get => _maxCalories;
            set
            {
                _maxCalories = value;
                OnPropertyChanged(nameof(MaxCalories));
                UpdateFilteredModules();
            }
        }

        public string SelectedFoodGroup
        {
            get => _selectedFoodGroup;
            set
            {
                _selectedFoodGroup = value;
                OnPropertyChanged(nameof(SelectedFoodGroup));
                UpdateFilteredModules();
            }
        }

        ObservableCollection<Module> IMainViewModel.Modules { get; set; } = new ObservableCollection<Module>();
        ObservableCollection<Module> IMainViewModel.FilteredModules { get; set; } = new ObservableCollection<Module>();

        public MainViewModel(ObservableCollection<Module> filteredModules)
        {
            ((IMainViewModel)this).FilteredModules = filteredModules;
        }

        // Existing properties and methods

        private void UpdateFilteredModules()
        {
            ((IMainViewModel)this).FilteredModules.Clear();

            if (string.IsNullOrWhiteSpace(IngredientFilter))
            {
                foreach (var module in Module)
                {
                    ((IMainViewModel)this).FilteredModules.Add(module);
                }
            }
            else
            {
                foreach (var module in Module)
                {
                    if (module.Name.Contains(IngredientFilter, StringComparison.OrdinalIgnoreCase))
                    {
                        ((IMainViewModel)this).FilteredModules.Add(module);
                    }
                }
            }
        }
        private bool MatchesFilterCriteria(Module module)

        {

            if (!string.IsNullOrWhiteSpace(IngredientFilter) && !module.Name.Contains(IngredientFilter, StringComparison.OrdinalIgnoreCase))
            {
                return false;
            }

            if (!string.IsNullOrWhiteSpace(SelectedFoodGroup) && module.FoodGroup != SelectedFoodGroup)
            {
                return false;
            }

            if (_maxCalories.HasValue && module.Calories > _maxCalories.Value)
            {
                return false;
            }

            return true;
        }

        public Module NewModule { get; set; }
        public int SemesterWeeks { get; set; }
        public DateTime SemesterStartDate { get; set; }

        public ICommand AddModuleCommand { get; set; }
        public object ApplyFilter { get; }

        public MainViewModel()
        {
            ApplyFilterCommand = new RelayCommand(ApplyFilter);
            NewModule = new Module();
            AddModuleCommand = new RelayCommand(AddModule);
            SemesterStartDate = DateTime.Today;
        }
        private void ApplyFilter()
        {
            UpdateFilteredModules();
        
    }
        private void AddModule()
        {
            NewModule.Weeks = SemesterWeeks;
            NewModule.StartDate = SemesterStartDate;
            NewModule.SelfStudyHoursPerWeek = (NewModule.Credits * 10) - (NewModule.ClassHoursPerWeek * NewModule.Weeks);
            ((IMainViewModel)this).Modules.Add(NewModule);
            NewModule = new Module();
        }
    }
}
    