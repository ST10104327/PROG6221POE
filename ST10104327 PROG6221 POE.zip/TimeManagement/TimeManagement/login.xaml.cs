﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace TimeManagement
{
    /// <summary>
    /// Interaction logic for login.xaml
    /// </summary>
    public partial class login : Window
    {
        public login()
        {
            InitializeComponent();
        }

        private void TextBox_GotFocus(object sender, RoutedEventArgs e)
        {
            TextBox textBox = (TextBox)sender;
            if (textBox.Text == "Enter username")
            {
                textBox.Text = "";
                textBox.Foreground = System.Windows.Media.Brushes.Black;
            }
        }

        private void TextBox_LostFocus(object sender, RoutedEventArgs e)
        {
            TextBox textBox = (TextBox)sender;
            if (string.IsNullOrWhiteSpace(textBox.Text))
            {
                textBox.Text = "Enter username";
                textBox.Foreground = System.Windows.Media.Brushes.Gray;
            }
        }

        private void PasswordBox_PasswordChanged(object sender, RoutedEventArgs e)
        {
            PasswordBox passwordBox = (PasswordBox)sender;
            if (string.IsNullOrWhiteSpace(passwordBox.Password))
            {
                passwordBox.Tag = "Enter password";
                passwordBox.Foreground = System.Windows.Media.Brushes.Gray;
            }
            else
            {
                passwordBox.Tag = null;
                passwordBox.Foreground = System.Windows.Media.Brushes.Black;
            }
        }

        private void LoginButton_Click(object sender, RoutedEventArgs e)
        {
            // Handle login logic here

            string username = UsernameTextBox.Text;
            string password = PasswordBox.Password;

            using ( context = new ())
            {
                User user = context.Users.FirstOrDefault(u => u.Username == username && u.Password == password);
                if (user != null)
                {
                    // Successful login.
                    MessageBox.Show("Login successful!");
                    // Redirect to your time management features or another appropriate page.
                }
                else
                {
                    // Failed login.
                    MessageBox.Show("Invalid username or password.");
                }
            }
        }

    }
}
