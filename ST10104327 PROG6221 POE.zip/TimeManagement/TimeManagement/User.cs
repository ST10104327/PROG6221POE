﻿namespace TimeManagement
{
    internal class User
    {
    }
}