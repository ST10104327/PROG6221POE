﻿using System;
using System.Collections.ObjectModel;
using System.Windows.Input;

namespace TimeManagement
{
    public interface IMainViewModel
    {
        ICommand AddModuleCommand { get; set; }
        ObservableCollection<Module> FilteredModules { get; set; }
        string IngredientFilter { get; set; }
        ObservableCollection<Module> Modules { get; set; }
        Module NewModule { get; set; }
        DateTime SemesterStartDate { get; set; }
        int SemesterWeeks { get; set; }
    }
}