﻿namespace TimeManagement
{
    public class MainViewModelBase
    {
    }
}