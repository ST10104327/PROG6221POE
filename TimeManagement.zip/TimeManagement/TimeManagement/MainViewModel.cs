﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Input;

namespace TimeManagement
{
    class MainViewModel
    {
        public class MainViewModel : ViewModelBase
        {
            public static ObservableCollection<Module> Modules { get; set; } = new ObservableCollection<Module>();
            public Module NewModule { get; set; }
            public int SemesterWeeks { get; set; }
            public DateTime SemesterStartDate { get; set; }

            public ICommand AddModuleCommand { get; set; }

            public MainViewModel()
            {
                NewModule = new Module();
                AddModuleCommand = new RelayCommand(AddModule);
                SemesterStartDate = DateTime.Today;
            }

            private void AddModule()
            {
                NewModule.Weeks = SemesterWeeks;
                NewModule.StartDate = SemesterStartDate;
                NewModule.SelfStudyHoursPerWeek = (NewModule.Credits * 10) - (NewModule.ClassHoursPerWeek * NewModule.Weeks);
                Modules.Add(NewModule);
                NewModule = new Module();
            }
        }

    }
}
