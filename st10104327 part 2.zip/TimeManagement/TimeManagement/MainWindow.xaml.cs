﻿using Microsoft.Office.Interop.Excel;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Xml.Linq;
using static System.Net.Mime.MediaTypeNames;
using static TimeManagement.PasswordHelp;

namespace TimeManagement
{
    /// <summary>
    /// 
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window

    {
        private ObservableCollection<Module> modules = new ObservableCollection<Module>();

        public MainWindow()
        {
            InitializeComponent();
            moduleListView.ItemsSource = modules;
            DataContext = new MainViewModel();
            // Set the DataContext to the static Modules list
            modulesListBox.ItemsSource = MainViewModel.Modules;
        }

        private void AddModule_Click(object sender, RoutedEventArgs e)
        {
            // Create and add a new module to the list
            ModuleDialog dialog = new ModuleDialog();
            if (dialog.ShowDialog() == true)
            {
                modules.Add((Module)dialog.Module);
            }
        }
        private void EditModule_Click(object sender, RoutedEventArgs e)
        {
            // Edit the selected module
            if (moduleListView.SelectedItem != null)
            {
                Module selectedModule = (Module)moduleListView.SelectedItem;
                ModuleDialog dialog = new ModuleDialog(selectedModule);
                if (dialog.ShowDialog() == true)
                {
                    // Update the module
                    selectedModule.Code = dialog.Module.Code;
                    selectedModule.Name = dialog.Module.Name;
                    selectedModule.Credits = dialog.Module.Credits;
                    selectedModule.ClassHours = dialog.Module.ClassHours;
                }
            }
        }

        private void DeleteModule_Click(object sender, RoutedEventArgs e)
        {
            // Delete the selected module
            if (moduleListView.SelectedItem != null)
            {
                Module selectedModule = (Module)moduleListView.SelectedItem;
                modules.Remove(selectedModule);
            }
        }
    }
    private void RecordHours_Click(object sender, RoutedEventArgs e)
    {
        if (hoursTextBox != null && datePicker != null && datePicker.SelectedDate.HasValue)
        {
            if (int.TryParse(hoursTextBox.Text, out int hours))
            {
                Module selectedModule = (Module)((Button)sender).CommandParameter;
                if (selectedModule != null)
                {
                    DateTime selectedDate = datePicker.SelectedDate.Value;
                    ViewModel.RecordHours(selectedModule, selectedDate, hours);
                }

            }
            private bool AuthenticateUser(string enteredUsername, string enteredPassword)
            {
                using (context = new())
                {
                    // Find the user with the entered username.
                    User user = context.Users.FirstOrDefault(u => u.Username == enteredUsername);

                    if (user != null)
                    {
                        // Hash the entered password for comparison.
                        string enteredPasswordHash = PasswordHelper.HashPassword(enteredPassword);

                        // Compare the hashed password with the stored password hash.
                        if (enteredPasswordHash == user.Password)
                        {
                            // Authentication successful.
                            return true;
                        }
                    }

                    // Authentication failed.
                    return false;
                }
            }
            private void LoginButton_Click(object sender, RoutedEventArgs e)
            {
                string enteredUsername = UsernameTextBox.Text;
                string enteredPassword = PasswordBox.Password;

                bool isAuthenticated = AuthenticateUser(enteredUsername, enteredPassword);

                if (isAuthenticated)
                {
                    // Successful login.
                    MessageBox.Show("Login successful!");
                    // Redirect to your time management features or another appropriate page.
                }
                else
                {
                    // Failed login.
                    MessageBox.Show("Invalid username or password.");
                }
            }
            private void SaveTask(Task task)
            {
                using ( context = new ())
                {
                    User currentUser = context.Users.FirstOrDefault(u => u.Username == CurrentUser.Username);
                    if (currentUser != null)
                    {
                        task.UserId = currentUser.Id; // Associate the task with the user.
                        context.Tasks.Add(task);
                        context.SaveChanges();
                    }
                }
                private List<Task> GetCurrentUserTasks()
                {
                    using ( context = new ())
                    {
                        User currentUser = context.Users.FirstOrDefault(u => u.Username == CurrentUser.Username);
                        if (currentUser != null)
                        {
                            // Filter tasks by the current user's UserId.
                            return context.Tasks.Where(t => t.UserId == currentUser.Id).ToList();
                        }
                        return new List<Task>(); // Return an empty list if the user is not found.
                    }
                }

            }

        }
    } }



