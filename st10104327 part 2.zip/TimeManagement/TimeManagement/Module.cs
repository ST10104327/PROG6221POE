﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TimeManagement
{
    class Module
    {
        public string Code { get; set; }
        public string Name { get; set; }
        public int Credits { get; set; }
       
        public int Weeks { get; private set; }
        public int ClassHours { get; set; }
        // New property for self-study hours per week
        public int SelfStudyHoursPerWeek => (Credits * 10) - (ClassHours * Weeks);
        public Dictionary<DateTime, int> HoursPerDate { get; set; } = new Dictionary<DateTime, int>();
    }
}
